import Restaurant from "./components/Restaurant";
import Search from "./components/Search";
import Home from "./components/Home";
import {Routes, Route} from "react-router-dom";
import axios from "axios";
import {useEffect, useState} from "react";



function App() {
  let [locationList, setLocationList] = useState([]);

  let getLocationList = async () => {
    try{
    let url = "http://localhost:3002/api/get-location-list";
    let { data } = await axios.get(url);
    setLocationList(data.locationList);
    } catch (error){
        alert("server error");
    }
};

useEffect(() => {
  getLocationList();
  
}, []);

  return (
    <>
    <Routes>
    <Route path = "/" element = {<Home locationList={locationList}/>}/>
    <Route path = "/search/:id/:name" element = {<Search locationList={locationList}/>}/>
    <Route path = "/restaurant/:id" element = {<Restaurant/>}/>
    </Routes>
    </>
  );
}

export default App;
