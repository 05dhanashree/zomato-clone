import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";

const Search = (props) => {
    let { locationList } = props;
    let {id, name } = useParams();
    let navigate = useNavigate();
    

    let [filterData, setFilterData] = useState({
      mealType : id,
      sort : 1,
      mealname: name
    });

    let [restaurants, setRestaurants] = useState([]);

     let getFilterData = async () => {
         let url = "http://localhost:3002/api/filter"
         let filter = {};
         let {data} = await axios.post(url, filterData);
        console.log(data.RestaurantList);
        setRestaurants(data.RestaurantList);
     };
        
    let setFilterForPage = (event) => {
        let { value, name } = event.target;
        
        
        switch (name) {
            case "location":
                if(value === "")
                { delete filterData.loca_id;}
                else{
                setFilterData({...filterData, loca_id: Number(value)});
                }
                break;

            case "sort":
                setFilterData({...filterData, sort: Number(value)});
                break;
            case "min_price":
                let array = value.split("-");
                setFilterData({
                    ...filterData,
                    lCost: Number(array[0]),
                    hCost: Number(array[1]),
                });
                break;
            case "cuisine":
                
                setFilterData({...filterData, cuisineid: Number(value)});
                
                break;
        }
    };  
   
    useEffect (() => {
        getFilterData(); 
    }, [filterData]);
    return (
        <>
        
        <main className="container-fluid">
            <section className="row bg-danger py-lg-3 py-2">
                <header className="col-12 col-lg-11 m-auto text-white d-flex justify-content-between">
                    <p className="brand mb-0 fw-bold fs-4 ">e!</p>
                    <div>
                        <button className="btn text-white">Login</button>
                        <button className="btn btn-outline-light">Create an Account</button>
                    </div>
                </header>
            </section> 
            <section className="row">
                <section className="col-11 m-auto">
                {/* {restaurants.map((restaurant, index) => 
                {
                    return <p key={index} className="text-blue h3 mt-3 fw-bold">Breakfast Places in {restaurant.city} </p>
                })} */}
                    <section className="row gap-3">
                        <section className="col-lg-3 col-12 border border-1 p-2">
                            <div className="d-none d-lg-block">
                            <p className="text-blue fw-bold">Filter</p>
                            <div className="mb-3 fw-bold">
                                {/* <label htmlFor="" className="Form-label">Select Location</label> */}
                                <select  id="" className="Form-select"
                                name="location"
                                onChange={setFilterForPage}>
                                <option value = "">---Select Location---</option>
                                {locationList.map((location, index) => {
                                return (
                                <option key = {index} value = {location.location_id}>
                                    {location.name}, {location.city}
                                </option>
                                );
                                })}
                                </select>
                            </div>
                            <p className="mb-2 fw-bold">Cuisine</p>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="cuisine"
                                value="1"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">North Indian</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="cuisine"
                                value="2"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">South Indian</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="cuisine"
                                value="3"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">Chinese</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="cuisine"
                                value="4"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">Fast Food</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="cuisine"
                                value="5"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">Street Food</label>
                            </div>
                            <p className="mb-2 fw-bold">Cost</p>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="min_price"
                                value="0-500"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">Less than 500</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="min_price"
                                value="500-1000"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">500 to 1000</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="min_price"
                                value="1000-1500"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">1000 to 1500</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="min_price"
                                value="1500-2000"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">1500 to 2000</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                name="min_price"
                                value="2000+"
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">2000+</label>
                            </div>                              
                            <p className="mb-2 fw-bold">Sort</p>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input" 
                                value ="1" 
                                name="sort" 
                                checked = {filterData.sort == 1  ? true: false} 
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">Price Low to High</label>
                            </div>
                            <div className="Form-check">
                                <input type="radio"  id="" className="Form-check-input"
                                 value="-1" 
                                 name= "sort"
                                 checked = {filterData.sort == -1  ? true: false} 
                                onChange={setFilterForPage}/>
                                <label htmlFor="" className="Form-check-label text-muted">Price High to Low</label>
                            </div>
                        </div>
                        </section>
                        <section className="col-lg-8 col-12">
                            {
                                restaurants.length == 0 ? 
                                (
                                <>
                                <p>No Result Found</p>
                                </> 
                                )
                            : (
                            //<section className="row">
                                //{
                                    restaurants.map((restaurant, index)=>{
                                        return  <article onClick= {() => navigate("/restaurant/" + restaurant._id)} key={index} className="col-12 border border-1 bg-white mb-2 p-4">
                                    <div className="d-flex gap-2 gap-lg-4">
                                        <img
                                        src={"/images/shutterstock_1154073754.png"}
                                        alt=""
                                        className="edu-restaurant-image"
                                        />
                                        <div>
                                            <p className="h2 fw-bold text-blue">{restaurant.name}</p>
                                            <p className="text-success mb-2">
                                                {restaurant.aggregate_rating}<span className="fw-bold">(5K) </span>
                                            </p>
                                            <p className="text-muted">
                                                <span>{restaurant.locality},{restaurant.city}</span>
                                            </p>
                                        </div>
                                    </div>
                                    <hr/>
                                    <div className="d-flex gap-4">
                                        <div>
                                            <p className="mb-1">CUISINES:</p>
                                            <p>AVERAGE COST:</p>
                                        </div>
                                        <div>
                                            <p className="mb-1">{restaurant.cuisine.map((value) =>{
                                                return value.name;
                                            }).join(", ")}</p>
                                            <p>{restaurant.min_price}/- for one person (approx.)</p>
                                        </div>
                                    </div>
                                </article>
                                })

                             )} 
                                
                                
                            </section>
                        </section>
                    </section>
                </section>
            {/* </section> */}
        </main>      
        

    
        </>
    );
};

export default Search;