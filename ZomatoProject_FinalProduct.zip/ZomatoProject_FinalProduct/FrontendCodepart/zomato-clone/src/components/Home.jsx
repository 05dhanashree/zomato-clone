import { useEffect,useState } from "react";
import { Link, useNavigate } from "react-router-dom";
//import  { BASE_URL }  from "./ApiUrlNew.js";
import axios from "axios";

const Home = (props) => {

    let navigate = useNavigate(props);
    let {locationList} = props;


    
    let [mealTypeList, setmealTypeList] = useState([]);

    

    let getMealType = async () => {
        let url = "http://localhost:3002/api/get-meal-type";
        let { data } = await axios.get(url)
        setmealTypeList(data.mealTypeList);
    }
    useEffect(() => {
        
        getMealType();
    }, []);
    return (
        <>
        <main className="container">
            <section className="row py-lg-3 py-2 image">                
                <section className="col-lg-11 col-10 d-flex justify-content-end mt-2">
                    
                    <div>
                        <button className="btn text-white">Login</button>
                        <button className="btn btn-outline-light">Create an Account</button>
                    </div>
                </section>
               
                <section className="row">
                    <section className="col-11 mt-4 d-flex justify-content-center">
                        <p className="brand mb-2 fw-bold ">e!</p>
                    </section>
                </section>
                <section className="row">
                    <section className="col-11 m-auto">
                        <p className="brandcafe mb-0 fw-bold fs-4 text-center text-white">Find the best restaurants, cafes and bars</p>                        
                    </section>
                </section>                

            <div className="row d-flex  restaurant-input mt-4">
                <div className="col-lg-3 col-12">
                    <select
                        type="text"
                        placeholder="Please type a location"
                        className="w-100 py-2"
                        
                    >
                        <option value = "">---Select Location---</option>
                        {locationList.map((location, index) => {
                            return (
                                <option key = {index} value = {location.location_id}>
                                    {location.name}, {location.city}
                                </option>
                            );
                        })}
                    </select>
                </div>
                <div className="col-lg-7 col-12 mt-lg-0 mt-4 box">
                    <i className="fa fa-search text-black" aria-hidden="true"></i>
                    <input
                        type="text"
                        placeholder="Search for Restaurants"
                        className="w-100 py-2" 
                        ></input>            
                </div>
            </div>  
        </section>         

            <section className="container mt-5">
                <section className="col-11 m-auto">
                    <p className="text-blue h3 mt-5 fw-bold">Quick Searches</p>
                    <p className="text-blue h6 mt-4">Discover Restaurants by type of meal</p>
                </section>                 

                <section className="d-flex flex-wrap align-items-center justify-content-around">
                
                    {mealTypeList.map((meal, index) => {
                        return (

                            <div  key={index} className="items d-flex shadow mb-4 me-4 bg-white rounded size">
                    
                    <div onClick={() => {
                        navigate(`/search/${ meal.meal_type}/${meal.name}`);
                        }}  
                    className="m-auto d-flex gap-4">
                        <img
                        src={"/images/" + meal.image}
                        alt=""
                        className="edu-restaurant-image"
                        />
                    <div>  
                        <p className="text-blue h6 mt-3">{meal.name}</p>
                        <p>{meal.content}</p> 
                    </div>
                    </div>
                    </div>
                    
                        );
                    })};
                    
                    </section>
                    </section>        
                    

            
                    
                
                    
        </main>
        </>
    );
};

export default Home;