const express = require('express');
const mongoose = require('mongoose');
const APIRoutes = require('./routes/APIRoutes');
const cors = require("cors");
const app = express();
const MONGODB_URI = "mongodb://127.0.0.1:27017/batch8thjan";
const PORT = 3002;


//by default, post data is disabled in express
//body parse
app.use(cors());
app.use(express.json()); // enable all incoming json
app.use(express.urlencoded({extended: false})); // allow raw post data to convert to a js object
app.use("/", APIRoutes);



mongoose.connect(MONGODB_URI).then(() => {
    app.listen(PORT, () => {
        console.log("server started at port ", PORT);
    });
})
.catch((error) => {
    console.log(error);

});