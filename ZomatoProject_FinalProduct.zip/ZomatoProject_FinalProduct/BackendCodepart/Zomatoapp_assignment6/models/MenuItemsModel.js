const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId
const MenuItemsSchema = new mongoose.Schema(
    {
        name: {type: String},
        description:{type: String},
        ingredients: {type:Array},
        restaurantId: {type:ObjectId},
        image: {type:String},
        qty: {type:Number},
        price:{type:Number}

    });
const MenuItemsModel = mongoose.model("menuitem", MenuItemsSchema, "menuitems");
module.exports = MenuItemsModel;



